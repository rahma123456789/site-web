from django.contrib import admin
from produit.views import *
from django.urls import path, include
from django_filters.views import FilterView
from . import views
urlpatterns=[
    path('acceuil/', views.acceuil,name="acceuil"),
    path('eshop/', views.eshop,name="eshop"),
  

    path('panier2/',Panier2.as_view(),name="panier2"),
    path('panier/<str:pk>/',views.supprimercommande,name="supprimercommande"),
    path('inscription/', views.inscriptionPage,name="inscriptionPage"),
    path('login/', views.login,name="login"),
    path('panier2/<str:id>/', views.modif,name="modif" ),
    path('quitter/', views.logoutUser,name="quitter"),
    path('chercherarticle/', home1.as_view(), name='home1'),
    path('catalogue/', achat.as_view(), name='achat'),
    path('commande/', commande.as_view(), name='commande'),
    

   

    
    ]