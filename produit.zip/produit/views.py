import turtle
from django.shortcuts import render,get_object_or_404
from logging import Filterer
from msilib.schema import SelfReg
#from typing_extensions import Self
from django.shortcuts import render
from multiprocessing import context
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.urls import reverse
from graphviz import view
from produit.forms import produitForm
from produit.filtre import ArticleFiltre
from produit.models import Article2,Temp,Commande
from django.views import View
from flask import redirect, request
from django.db.models import Q
from django.db.models import F
from django.contrib import messages 
from produit.forms import UpdateproduitForm,panierForm
from django.db.models.signals import pre_save
from turtle import update
from django.dispatch import receiver
from .InscriptionForms import InscriptionForms
from django.contrib.auth import authenticate,login as auth_login,logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.hashers import check_password
from django.contrib.auth.models import User
from django.db.models import Sum
from  django.contrib.auth.decorators import login_required
from django.shortcuts import redirect
#import mysql.connector
from pyexpat.errors import messages
from operator import itemgetter
from django.shortcuts import (get_object_or_404,
							render,
							HttpResponseRedirect)
#@login_required(login_url='login/')
class Panier2(View):
    def get(self, request):
        print('get')
        my_orders = Temp.objects.using('user').filter(user_name=request.session['username'])
        
        return render(request,'panier2.html',{'cc':my_orders})

    def post(self, request):
        form=produitForm(request.POST)
        print("post")
        
        my_orders = Temp.objects.using('user').filter(user_name=request.session['username'])
        #aa=Temp.objects.using('user').filter(id=id).update(quantité =request.POST.get('quantité'))
        
        print(request.POST )
         
        ca = (request.POST.getlist('COD_ART'))
        qn =(request.POST.getlist('quantité'))
        print("post")
        c=  request.session['username']
        rahma=Temp.objects.using('user').all()    
        for item in range(len(ca)):
            print(ca[item])
            
            ww= Temp.objects.using('user').filter(COD_ART=ca[item],user_name=c).first()
            print(ww.id)
            Temp.objects.using('user').filter(pk=ww.id).update(quantité = qn[item])

           
            #zz = Temp.objects.using('user').get(pk=t.id)
    
        '''for x in my_orders:

            print(x)
        
            b= x.quantité 
            
            a=	x.COD_ART
           

            c=  request.session['username'] 
            
            
            com = Commande.objects.using('user').create(quantité=b,COD_ART=a,user_name=c)
            com.save()
            record = Temp.objects.using('user').get(id = x.id)
            record.delete()'''
            #x.objects.using('user').delete()
        my_orders = Temp.objects.using('user').filter(user_name=request.session['username'])
        form = panierForm()
        return render(request,'panier2.html',{'cc':my_orders,'form':form})
       
class commande(View):
    def get(self, request):
        print('get')
        my_orders = Commande.objects.using('user').filter(user_name=request.session['username'])
        
        return render(request,'commande.html',{'cc':my_orders})
    

def modif( request,id):
   
    monpanier = Temp.objects.using('user').filter(user_name=request.session['username'])
    aa=Temp.objects.using('user').filter(id=id).update(quantité =request.POST.get('quantité'))
   
    print(request)
    print(request.GET)
    print(request.POST)
    
        
    form = panierForm()
    
    return render(request,'panier2.html',{'cc':monpanier,'form':form,'aa':aa})
           
'''def modifier (request)   :
    cc= Temp.objects.using('user').get(id=cc.id)
    form=produitForm(instance=cc)
    if request.method=="POST":
        form=produitForm(request.POST,instance=cc)
        if form.is_valid():
            form.save()
            return redirect('/')
            
        
            
    return render(request,'panier.html',{'form':form})'''




# update view for details
'''def modifier(request, id):
	# dictionary for initial data with
	# field names as keys
	context ={}

	# fetch the object related to passed id
	obj = get_object_or_404(Temp, id = id)

	# pass the object as instance in form
	form = panierForm(request.POST or None, instance = obj)

	# save the data from the form and
	# redirect to detail_view
	if form.is_valid():
		form.save()
		return HttpResponseRedirect("/"+id)

	# add form dictionary to context
	context["form"] = form
    
	return render(request, "panier.html", context)'''

def  supprimercommande(request,pk):
    
    panier= Temp.objects.using('user').get(id=pk)
    
    print('here')
    panier.delete()
    
    
    return  HttpResponseRedirect('/panier2/')







def index(request):
    return render(request,'index1.html')

    
def logoutUser(request):
    logout(request)
    return redirect('login')


def login(request):
    form = InscriptionForms()
    if request.method=='POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)

        if user is not None :
            auth_login(request,user)
            request.session['username']= username
            print(request.session['username'])
            return  HttpResponseRedirect('/eshop/')
        else:
            messages.info(request,"Utilisateur et/ou mot de passe n'est pas valide")
            return render(request,'login.html',{'form':form})
    return render(request,'login.html',{'form':form})

@login_required(login_url='login')
def acceuil (request):
    #request.session['user'] = 'omar'
    #print(request.session['user'])
    return render(request,'acceuil.html')
def eshop (request):
    #request.session['user'] = 'omar'
    #print(request.session['user'])
    return render(request,'eshop.html')       
def cart(request):
    #request.session['user'] = 'omar'
    #print(request.session['user'])
    return render(request,'panier2.html') 
def catalogue (request):
    #request.session['user'] = 'omar'
    #print(request.session['user'])
    return render(request,'catalogue.html')   
   
def détails (request):
  
    return render(request,'details.html') 
class achat(View):
    context={}
    form = produitForm()
    template_name = 'catalogue.html'
    
    def get(self,request  ,*args, **kwargs):
        rahma=Article2.objects.using('user').all()
        template_name = 'catalogue.html'
        self.context['rahma']='rahma'
        form=produitForm(request.POST)
        self.context['form']=form
        #f= Article2.object.get('code famille','DES_ART')
        f = ArticleFiltre(request.GET, queryset=Article2.objects.using('user').all())       
        try:
            
                
                
            if (len(request.GET['code_famille'])==0):
                q1= (Article2.objects.using('user').filter(Q(des_art__istartswith=request.GET['des_art'])))&(Article2.objects.filter(Q(cod_art__istartswith=request.GET['cod_art'])))
               
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            elif (len(request.GET['des_art'])==0):
                q1= (Article2.objects.using('user').filter(Q(code_famille__istartswith=request.GET['code_famille'])))&(Article2.objects.filter(Q(cod_art__istartswith=request.GET['cod_art'])))
                 
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            elif (len(request.GET['cod_art'])==0):
                q1= (Article2.objects.using('user').filter(Q(code_famille__istartswith=request.GET['code_famille'])))&(Article2.objects.filter(Q(des_art__istartswith=request.GET['des_art'])))
                 
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            elif (len(request.GET['code_famille'])!=0) and (len(request.GET['des_art'])!=0 ) and (len(request.GET['cod_art'])!=0):
                q1=(Article2.objects.using('user').filter (Q(code_famille__istartswith=request.GET['code_famille'])))& (Article2.objects.filter(Q(des_art__istartswith=request.GET['des_art'])))& (Article2.objects.filter(Q(cod_art__istartswith=request.GET['cod_art'])))
                 
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            else:
                return("data is empty")

    
            
        except:
            print("omar")
            return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f})
    def post(self,request,*args, **kwargs):
        print('yes')
        print(request.POST)
        rahma=Temp.objects.using('user').all()        
        template_name = 'catalogue.html'
         
        form=panierForm()
        
        a=  request.POST.get('cod_art')
        b=  request.POST.get('quantité') 
        c=  request.session['username']
        print(a,c,b)
        try :
            rahmaa= Temp.objects.using('user').filter(COD_ART=a,user_name=c).first()
             
            Temp.objects.using('user').filter(pk=rahmaa.id).update(quantité =F('quantité') +b)
            
            
            print(rahmaa.quantité)
             
             
            print('om')

        except :


           rahmaa= Temp.objects.using('user').create(COD_ART=a,quantité=b,user_name=c)
           rahmaa.save()
            
        f = ArticleFiltre(request.GET, queryset=Article2.objects.using('user').all())       
        try:
            
                
                
            if (len(request.GET['code_famille'])==0):
                q1= (Article2.objects.using('user').filter(Q(des_art__istartswith=request.GET['des_art'])))&(Article2.objects.filter(Q(cod_art__istartswith=request.GET['cod_art'])))
               
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            elif (len(request.GET['des_art'])==0):
                q1= (Article2.objects.using('user').filter(Q(code_famille__istartswith=request.GET['code_famille'])))&(Article2.objects.filter(Q(cod_art__istartswith=request.GET['cod_art'])))
                 
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            elif (len(request.GET['cod_art'])==0):
                q1= (Article2.objects.using('user').filter(Q(code_famille__istartswith=request.GET['code_famille'])))&(Article2.objects.filter(Q(des_art__istartswith=request.GET['des_art'])))
                 
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            elif (len(request.GET['code_famille'])!=0) and (len(request.GET['des_art'])!=0 ) and (len(request.GET['cod_art'])!=0):
                q1=(Article2.objects.using('user').filter (Q(code_famille__istartswith=request.GET['code_famille'])))& (Article2.objects.filter(Q(des_art__istartswith=request.GET['des_art'])))& (Article2.objects.filter(Q(cod_art__istartswith=request.GET['cod_art'])))
                 
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            else:
                return("data is empty")

    
            
        except:
            print("omar")
            return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f})
      
       

def inscriptionPage(request):
    form=InscriptionForms()
    print(request.POST)
    if request.method=='POST':
        form=InscriptionForms(request.POST)
        if form.is_valid():
            form.save()
            #user=form.cleaned_data.get('username')
            #messages.success(request,'compte crrée avec succes'+user)        
    context={'form':form}
    return render(request,'inscription.html',context)




class home1(View):
    context={}
    form = produitForm()
    template_name = 'ajouterarticle.html'
    def get(self, request, *args, **kwargs):
        rahma=Article2.objects.using('user').all()
        template_name = 'chercherarticle.html'
        
        self.context['rahma']='rahma'
        form=produitForm(request.POST)
        self.context['form']=form
        #f= Article2.object.get('code famille','DES_ART')
        f = ArticleFiltre(request.GET, queryset=Article2.objects.using('user').all())
        try:
                
                
            if (len(request.GET['code_famille'])==0):
                q1= (Article2.objects.using('user').filter(Q(des_art__istartswith=request.GET['des_art'])))&(Article2.objects.filter(Q(cod_art__istartswith=request.GET['cod_art'])))
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            elif (len(request.GET['des_art'])==0):
                q1= (Article2.objects.using('user').filter(Q(code_famille__istartswith=request.GET['code_famille'])))&(Article2.objects.filter(Q(cod_art__istartswith=request.GET['cod_art'])))
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            elif (len(request.GET['cod_art'])==0):
                q1= (Article2.objects.using('user').filter(Q(code_famille__istartswith=request.GET['code_famille'])))&(Article2.objects.filter(Q(des_art__istartswith=request.GET['des_art'])))
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            elif (len(request.GET['code_famille'])!=0) and (len(request.GET['des_art'])!=0 ) and (len(request.GET['cod_art'])!=0):
                q1=(Article2.objects.using('user').filter (Q(code_famille__istartswith=request.GET['code_famille'])))& (Article2.objects.filter(Q(des_art__istartswith=request.GET['des_art'])))& (Article2.objects.filter(Q(cod_art__istartswith=request.GET['cod_art'])))
                return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f,'q1': q1})
            else:
                return("data is empty")


            
        except:
            
            print("omar")
            
            return render (request,template_name ,{'form': form,'rahma': rahma, 'filter': f})

